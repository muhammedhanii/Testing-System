package com.aiu.trips.enums;

public enum EventType {
    EVENT,
    TRIP
}
