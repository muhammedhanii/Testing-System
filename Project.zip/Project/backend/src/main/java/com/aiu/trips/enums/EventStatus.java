package com.aiu.trips.enums;

public enum EventStatus {
    ACTIVE,
    CANCELLED,
    COMPLETED
}
