package com.aiu.trips.enums;

/**
 * Enumeration for Activity Type as per Data_Layer.pu diagram
 */
public enum ActivityType {
    EVENT,
    TRIP
}
