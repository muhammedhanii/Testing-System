package com.aiu.trips.enums;

public enum PaymentMethod {
    CASH
}
