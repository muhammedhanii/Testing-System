package com.aiu.trips.exception;

public class BookingException extends RuntimeException {
    public BookingException(String message) {
        super(message);
    }
}
