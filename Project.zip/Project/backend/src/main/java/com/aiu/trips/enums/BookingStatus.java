package com.aiu.trips.enums;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    ATTENDED
}
