package com.aiu.trips.enums;

public enum UserRole {
    STUDENT,
    ADMIN
}
